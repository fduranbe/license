source setenv.sh
python ms_estimation.py -1