export APPD_CONTROLER_URL="https://xyz
export APPD_CONTROLLER_PORT="443"
export APPD_USER=""
export APPD_PWD=""
export APPD_ACCOUNT_NAME="xyz"






